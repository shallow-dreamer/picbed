// 使用CommonJS是使用 require 导入，ESM是使用 import 导入
require("@rushstack/eslint-patch/modern-module-resolution");

module.exports =  {
  root: true,
  extends: [
    // Vue语法的ESLint插件
    "plugin:vue/vue3-recommended",
    // ESLint+TypeScript Lint+Vue Lint三个插件的集合与配置 
    "@vue/eslint-config-standard-with-typescript",
    // 继承Vue官方提供的ESLintPrettier标准配置
    "@vue/eslint-config-prettier",
  ],
};
