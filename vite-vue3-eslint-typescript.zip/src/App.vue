<template>
  <div>
    <div>当前计数器：{{ counter }}</div>
    <button @click="handleCounterChange(counter + 1)">点击增加</button>
    <button @click="handleCounterChange(counter - 1)">点击减少
        </button>
  </div>
</template>  

<script lang="ts" setup>
import { ref } from "vue";

  
const counter = ref<number>(1);
const handleCounterChange = (value: number): void => {
  counter.value = value;
};
</script>

<style scoped></style>
